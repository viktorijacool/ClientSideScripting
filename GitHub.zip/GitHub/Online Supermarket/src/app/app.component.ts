import { Component, OnInit } from '@angular/core';
import { Item } from './dto/items.dto';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  items: Item[] = [];
  totalValue: number = 0;

  ngOnInit(): void {
    this.initialiseItems();
  }

  initialiseItems() {
    this.items.push(
      new Item(
          1, 
          "Leaf Rake", 
          19.95
      ),
  
      new Item(
          2, 
          "Garden Cart",
          32.95
      ),
  
      new Item(
          5, 
          "Hammer", 
          8.5 
      )
    )
  } 
  
  onItemAdded(item: Item) {
    console.log('Detected item added event from app component');
    this.totalValue = this.totalValue + item.price;
  }

}
