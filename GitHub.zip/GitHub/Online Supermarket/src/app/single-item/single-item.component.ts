import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { Item } from '../dto/items.dto';

@Component({
  selector: 'app-single-item',
  templateUrl: './single-item.component.html',
  styleUrls: ['./single-item.component.css']
})
export class SingleItemComponent implements OnInit {

  @Input()
  item!: Item;

  @Output()
  itemAdded: EventEmitter<Item> = new EventEmitter<Item>();
  
  constructor() { }

  ngOnInit(): void {
  }

  onAddProductButtonClick() {
    console.log('Detected a button click in single-item');
    this.itemAdded.emit(this.item);
  }

}

