import { identifierName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { TodoItem } from './dto/todoitem.dto';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  toDoItems: TodoItem[] = [];

  
  
  ngOnInit(): void {
    this.initialiseItems();
  }

  initialiseItems() {
    this.toDoItems.push(
      new TodoItem (2, "Grocery shopping", true),
      new TodoItem (4, "Enterprise Progarmming revision", false),
      new TodoItem (6, "Server Side Scripting lecture", false),
      new TodoItem (9, "Vitamin D", true)
    );
  }

  onCompletedButtonClick(clickedItem: TodoItem) {

    console.log('Detected a button click in todo-item ' + clickedItem.id);
    clickedItem.isCompleted = true;

    
    // this.todoCompleted.emit(this.toDoItem);

    // this.isCompleted = !this.isCompleted;

  }

}
